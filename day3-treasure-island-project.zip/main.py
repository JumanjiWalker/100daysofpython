print('''
*******************************************************************************
          |                   |                  |                     |
 _________|________________.=""_;=.______________|_____________________|_______
|                   |  ,-"_,=""     `"=.|                  |
|___________________|__"=._o`"-._        `"=.______________|___________________
          |                `"=._o`"=._      _`"=._                     |
 _________|_____________________:=._o "=._."_.-="'"=.__________________|_______
|                   |    __.--" , ; `"=._o." ,-"""-._ ".   |
|___________________|_._"  ,. .` ` `` ,  `"-._"-._   ". '__|___________________
          |           |o`"=._` , "` `; .". ,  "-._"-._; ;              |
 _________|___________| ;`-.o`"=._; ." ` '`."\` . "-._ /_______________|_______
|                   | |o;    `"-.o`"=._``  '` " ,__.--o;   |
|___________________|_| ;     (#) `-.o `"=.`_.--"_o.-; ;___|___________________
____/______/______/___|o;._    "      `".o|o_.--"    ;o;____/______/______/____
/______/______/______/_"=._o--._        ; | ;        ; ;/______/______/______/_
____/______/______/______/__"=._o--._   ;o|o;     _._;o;____/______/______/____
/______/______/______/______/____"=._o._; | ;_.--"o.--"_/______/______/______/_
____/______/______/______/______/_____"=.o|o_.--""___/______/______/______/____
/______/______/______/______/______/______/______/______/______/______/_____ /
*******************************************************************************
''')
print("Welcome to Treasure Island.")
print("\nYour mission is to find the treasure.") 
print("\nYou found a map hidden within piles of dusty books and looking for an adventure, you are determined to follow the map for yourself\nThe map has led you to a cave. Hesitant about entering, you venture in through the cave")
choice1 = input("You suddenly find yourself in the midst of two corridors, but which one shall you go through? Left or right? ").capitalize()
if choice1 == 'Left':
  print("As you enter through your chosen path, you see some light ahead\n")
  choice2 = input("Do you leave the cave and walk towards the light, or do you search the cave some more? Type 'Leave' or 'Explore': ").capitalize()
  if choice2 == 'Explore':
    print("You further explore and find yourself in a part of the cave which looks unlike the rest of it.\nYou further explore to find yourself in the midst of three doorways. Hours of walking have led you here, so you must choose wisely:")
    door_choice = input("Which colour door will you choose to enter? Red, Blue or Yellow: ").capitalize()
    if door_choice == "Yellow":
      print("""
            
                        '
               '                 '
       '         '      '      '        '
          '        \    '    /       '
              ' .   .-"```"-.  . '
                    \`-._.-`/
         - -  =      \\ | //      =  -  -
                    ' \\|// '
              . '      \|/     ' .
           .         '  `  '         .
        .          /    .    \           .
                 .      .      .
            \nYou find yourself among tons of gems. You win!
            """)
    elif door_choice == 'Red':
      print("""

             #########\                                                      #########\
 #(=====)# |                           ///                       #(=====)# |
 ######### |                         _(oo)_                      ######### |
 #-------# |                        // \/ //                     #-------# |
 #|  -  |# |          -- __________//____//__________--          #|  -  |# |
 #|( O )|# |    --  --  /-/\-  -+/ -+- -+- /-/\-  -+/| --  --    #|( O )|# |
 #|  -  |# |  --  --   / /( o ) / ^^^ /// / /( o ) / /   --  --  #|  -  |# |
 #|-----|# |--        / &   - o/ ^^^ /// / &   - o/ /          --#|-----|# |
 #########/          |#########|#########|########|/             #########/\nYou enter into a room and find that a party is happening in full swing. It's not the treasure, but you decide to join anyway. Game Over.
            
            """)
    elif door_choice == 'Blue':
      print("""
            
                              ...
                 /o o\
                (  -  )
                 \ O /
                 _\_/_
               _/__|__\_
               |       |
               |  ___  |
               |  | |  |
       ________|__|_|__|________
       |'''''''''''''''''''''''|
       |  ===     ===     ===  |
   @@@ |_______________________| @@@@@
  @@@@@    |               |    @@RIP@@
   @@@     |      RIP      |     @@@@@
   /|\     |_______________|     / | \
       ||||    @@    ;;;;   //\\
      (    )  @@@@  [    ] ///\\\
      _\__/_  @@@@  _\__/_////\\\\
   __/______\/@@@@\/______\/____\___
   |          @@@@                 |
   |                               |
"And so, dear bereaved friends and relatives,
Let us remember the departed, as she was in life.
She was a fine, wonderful person, so filled
with joy and life, even if she was so ugly she
had to sneak up on a glass of water to get a drink."\n\nYou rush off full of so much excitement, that you don't notice the ridge underneath
            
            """)
    else:
      print("You did not choose. Game Over")
  else:
    print("""
   _,
  (/} /  
  ]n\d
   \o'
   U
   Nn\nYou find yourself walking towards an attacking army. You try to explain, but its no use. Game Over.        
          """)
else:
  print("""
        
                                                   .""--.._
                                           []      `'--.._
                                           ||__           `'-,
                                         `)||_ ```'--..       \
                     _                    /|//}        ``--._  |
                  .'` `'.                /////}              `\/
                 /  .""'.\              //{///
                /  /_  _`\\            // `||
                | |(_)(_)||          _//   ||
                | |  /\  )|        _///\   ||
                | |L====J |       / |/ |   ||
               /  /'-..-' /    .'`  \  |   ||
              /   |  :: | |_.-`      |  \  ||
             /|   `\-::.| |          \   | ||
           /` `|   /    | |          |   / ||
         |`    \   |    / /          \  |  ||
        |       `\_|    |/      ,.__. \ |  ||
        /                     /`    `\ ||  ||
       |           .         /        \||  ||
       |                     |         |/  ||
       /         /           |         (   ||
      /          .           /          )  ||
     |            \          |             ||
    /             |          /             ||
   |\            /          |              ||
   \ `-._       |           /              ||
    \ ,//`\    /`           |              ||
     ///\  \  |             \              ||
    |||| ) |__/             |              ||
    |||| `.(                |              ||
    `\\` /`                 /              ||
       /`                   /              ||
      /                     |              ||
     |                      \              ||
    /                        |             ||
  /`                          \            ||
/`                            |            ||
`-.___,-.      .-.        ___,'            ||
         `---'`   `'----'`\n You find yourself being led to a lake full of lava by the grim reaper. Game Over.
        
        """)