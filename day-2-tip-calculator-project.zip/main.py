print("Welcome to the tip calculator!")
bill = float(input("What was the total bill? £"))
tip = int(input("How much tip would you like to give? 10, 12 or 15? "))
people = int(input("How many people to split the bill? "))
total_money_use = bill * (1 + tip/100)
money_perperson = "{:.2f}".format(total_money_use/people) #rounds to 2dp no matter if there's a 0 at the end 
print(f"Each person should pay £{ money_perperson}")
