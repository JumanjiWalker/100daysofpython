from replit import clear
from art import logo

#Add
def add(n1,n2):
    return n1 + n2

#Subtract
def sub(n1, n2):
    return n1 - n2

#Multiply
def mult(n1, n2):
    return n1 * n2

#Divide
def divide(n1, n2):
    return n1/n2

operations = {
    '+' : add,
    '-' : sub,
    '*' : mult,
    '/' : divide   
}

def calculator():
    print(logo)
    
    num1 = float(input("What's the first number? "))
    for operation in operations:
        print(operation, end=' ')
    
    while True:
        operation_choice = input("Pick an operation: ")
        num2 = float(input("What's the next number? "))
        symbol_function = operations[operation_choice]
        answer = symbol_function(num1, num2)
        
        print(f"{num1} {operation_choice} {num2} = {answer}")
        go_again = input(f"Type 'y' to continue calculating with {answer}, or type 'n' to start a new calculation: ")
        if go_again == 'n':
            clear()
            calculator()
        elif go_again == 'y':
            num1 = answer
        else:
            print("Goodbye")
            clear()
            break

calculator()