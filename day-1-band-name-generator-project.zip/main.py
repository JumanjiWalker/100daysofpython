print("Hello!")
city = input("What is the name of the city that you grew up in?\n")
pet = input("What's the name of a pet you owned?\n")
bandname = city + ' ' + pet
print("Your bandname could be " + bandname)