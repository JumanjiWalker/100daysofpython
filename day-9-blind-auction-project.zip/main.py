from replit import clear
from art import logo

print(logo)

print("Welcome to the secret auction program!")
bidders = []

def auction_game(person,bid_amount):
    bidder = {}
    bidder['name'] = person
    bidder['bid'] = float(bid_amount)
    bidders.append(bidder)

while True:
    name = input("What is your name?\n").capitalize()
    bid = "{:.2f}".format(float(input("How much are you planning to bid today?\n£")))
    auction_game(name, bid)
    carry_on = input("Is there another person who would like to bid? Type 'yes' or 'no':\n")
    if carry_on == 'no':
        break
    clear()

bids = []
for bidder in bidders:
    bids.append(bidder['bid'])
maximum_bid = max(bids)
ind = bids.index(maximum_bid)
highest_bidder = bidders[ind]['name']
print(f'The winner is {highest_bidder} with a bid of £{maximum_bid}')
print(bidder)